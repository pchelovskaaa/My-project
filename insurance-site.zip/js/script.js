function calc() {
  let type = document.getElementById('type').value;
  let sum = document.getElementById('sum').value;

  let extra = 0;
  if(document.getElementById('opt1').checked) extra += 500;
  if(document.getElementById('opt2').checked) extra += 700;

  let result = sum * type + extra;

  document.getElementById('result').innerText = Math.round(result) + ' грн';
}
